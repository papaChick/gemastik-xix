const net = require("net");

const BACKEND_HOST = process.env.BACKEND_HOST || "backend";
const BACKEND_PORT = parseInt(process.env.BACKEND_PORT || "4000", 10);
const LISTEN_PORT = parseInt(process.env.LISTEN_PORT || "8090", 10);

function isBlockedPath(requestLine) {
    const parts = requestLine.split(" ");
    const path = parts[1] || "";
    return path.startsWith("/internal/");
}

function isAllowedSurface(requestLine) {
    const parts = requestLine.split(" ");
    const path = (parts[1] || "").split("?")[0];
    return path === "/health" || path.startsWith("/internal/");
}

function findHeaderEnd(buf) {
    return buf.indexOf("\r\n\r\n");
}

function parseHeaders(headText) {
    const lines = headText.split("\r\n");
    const requestLine = lines[0] || "";
    const headers = [];
    for (let i = 1; i < lines.length; i++) {
        const idx = lines[i].indexOf(":");
        if (idx === -1) continue;
        headers.push([lines[i].slice(0, idx).trim(), lines[i].slice(idx + 1).trim()]);
    }
    return { requestLine, headers };
}

function getHeader(headers, name) {
    const h = headers.find(([k]) => k.toLowerCase() === name.toLowerCase());
    return h ? h[1] : null;
}

function extractOneRequest(buf) {
    const headerEnd = findHeaderEnd(buf);
    if (headerEnd === -1) return null;
    const headText = buf.slice(0, headerEnd).toString("latin1");
    const { requestLine, headers } = parseHeaders(headText);
    const bodyStart = headerEnd + 4;

    const te = getHeader(headers, "transfer-encoding");
    if (te && te.toLowerCase().includes("chunked")) {
        let offset = bodyStart;
        while (true) {
            const lineEnd = buf.indexOf("\r\n", offset);
            if (lineEnd === -1) return null;
            const sizeHex = buf.slice(offset, lineEnd).toString("latin1").split(";")[0].trim();
            const size = parseInt(sizeHex, 16);
            if (Number.isNaN(size)) return null;
            const dataStart = lineEnd + 2;
            if (size === 0) {
                const termEnd = buf.indexOf("\r\n", dataStart);
                if (termEnd === -1) return null;
                const consumed = termEnd + 2;
                return { consumed, requestLine, raw: buf.slice(0, consumed) };
            }
            const dataEnd = dataStart + size;
            if (buf.length < dataEnd + 2) return null;
            offset = dataEnd + 2;
        }
    }

    const cl = getHeader(headers, "content-length");
    const bodyLen = cl ? parseInt(cl, 10) : 0;
    const consumed = bodyStart + bodyLen;
    if (buf.length < consumed) return null;
    return { consumed, requestLine, raw: buf.slice(0, consumed) };
}

const server = net.createServer((clientSock) => {
    let clientBuf = Buffer.alloc(0);
    let aclChecked = false;
    const backendSock = net.connect(BACKEND_PORT, BACKEND_HOST);
    backendSock.on("data", (d) => clientSock.write(d));
    backendSock.on("error", () => clientSock.destroy());
    backendSock.on("close", () => clientSock.destroy());

    clientSock.on("data", (chunk) => {
        clientBuf = Buffer.concat([clientBuf, chunk]);
        pump();
    });

    function pump() {
        while (true) {
            let parsed;
            try {
                parsed = extractOneRequest(clientBuf);
            } catch (e) {
                clientSock.destroy();
                return;
            }
            if (!parsed) return;

            if (!isAllowedSurface(parsed.requestLine)) {
                clientSock.end(
                    "HTTP/1.1 404 Not Found\r\nContent-Length: 9\r\nConnection: close\r\n\r\nnot found"
                );
                backendSock.destroy();
                return;
            }

            if (!aclChecked) {
                aclChecked = true;
                if (isBlockedPath(parsed.requestLine)) {
                    clientSock.end(
                        "HTTP/1.1 403 Forbidden\r\nContent-Length: 9\r\nConnection: close\r\n\r\nforbidden"
                    );
                    backendSock.destroy();
                    return;
                }
            }
            backendSock.write(parsed.raw);
            clientBuf = clientBuf.slice(parsed.consumed);
        }
    }

    clientSock.on("close", () => backendSock.destroy());
    clientSock.on("error", () => backendSock.destroy());
});

server.listen(LISTEN_PORT, () => {
    console.log(`ops gateway listening on :${LISTEN_PORT}`);
});
