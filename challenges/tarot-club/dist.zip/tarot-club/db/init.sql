CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(16) NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE groups (
    id SERIAL PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    is_private BOOLEAN DEFAULT true,
    created_by INTEGER REFERENCES users(id)
);

CREATE TABLE group_members (
    group_id INTEGER REFERENCES groups(id),
    user_id INTEGER REFERENCES users(id),
    PRIMARY KEY (group_id, user_id)
);

CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    group_id INTEGER REFERENCES groups(id),
    author_id INTEGER REFERENCES users(id),
    body TEXT NOT NULL,
    is_flag BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE posts (
    id SERIAL PRIMARY KEY,
    author_id INTEGER REFERENCES users(id),
    title VARCHAR(256),
    body_html TEXT NOT NULL,
    reported BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT now()
);

INSERT INTO users (username, password_hash, role) VALUES
    ('admin', crypt('S3cur3AdminPass!', gen_salt('bf')), 'admin'),
    ('alice', crypt('alicepassword',    gen_salt('bf')), 'user'),
    ('bob',   crypt('bobpassword',      gen_salt('bf')), 'user'),
    ('klein', crypt('theworldisgray',   gen_salt('bf')), 'user'),
    ('monitor', crypt('monitor_probe_2026', gen_salt('bf')), 'user');

INSERT INTO groups (name, is_private, created_by) VALUES
    ('Loge Kabut Kelabu', true,  2),
    ('Aula Pencari',      false, 1),
    ('Serambi Pendatang', false, 1);

INSERT INTO group_members (group_id, user_id) VALUES
    (1, 2),
    (2, 1), (2, 2), (2, 3),
    (3, 1), (3, 3), (3, 4);

INSERT INTO messages (group_id, author_id, body, is_flag) VALUES
    (1, 2, '__ROUND_FLAG__', true);

INSERT INTO messages (group_id, author_id, body) VALUES
    (1, 2, 'Simpan catatan ritual di sini. Jangan dibagikan ke luar loge.'),
    (2, 1, 'Selamat datang di Aula Pencari. Perkenalkan Sequence kalian.'),
    (2, 3, 'Bob, Sequence 9, masih meraba-raba jalur Pemabuk.'),
    (3, 4, 'Ada yang tahu arti kartu The Fool yang muncul tiga malam berturut?');

INSERT INTO posts (author_id, title, body_html) VALUES
    (1, 'Tata Tertib Korespondensi',
        '<p>Gunakan <b>segel</b> yang pantas. Jangan menautkan kabut yang tak kalian kenal.</p>'),
    (2, 'Mencari rekan ritual doa senja',
        '<p>Butuh dua anggota lagi. Balas surat ini bila berminat.</p>'),
    (3, 'Tinjauan tautan: mercusuar Pulau Hilang',
        '<p>Coba fitur <i>tinjau tautan</i> untuk mengintip isi halaman tanpa membukanya.</p>');
