const { gql } = require("apollo-server-express");

const typeDefs = gql`
    type Message {
        id: ID!
        body: String!
        authorId: ID!
        createdAt: String!
    }

    type Group {
        id: ID!
        name: String!
        isPrivate: Boolean!
        messages: [Message!]!
    }

    type User {
        id: ID!
        username: String!
        role: String!
        privateGroups: [Group!]!
    }

    type Post {
        id: ID!
        title: String!
        bodyHtml: String!
        authorId: ID!
    }

    type LinkPreview {
        url: String!
        status: Int!
        snippet: String!
    }

    type Query {
        me: User
        group(id: ID!): Group
        user(id: ID!): User
        posts: [Post!]!
        post(id: ID!): Post
        groups: [Group!]!
        searchPosts(q: String!, sort: String): [Post!]!
        serverInfo: String
    }

    type Mutation {
        register(username: String!, password: String!): String
        login(username: String!, password: String!): String
        createPost(title: String!, bodyHtml: String!): Post
        reportPost(id: ID!): Boolean
        setPrefs(prefsJson: String!): Boolean
        linkPreview(url: String!): LinkPreview
        exportMyDataPdf: String
        createGroup(name: String!, isPrivate: Boolean): Group
        joinGroup(id: ID!): Boolean
        sendMessage(groupId: ID!, body: String!): Message
        debugEval(code: String!): String
    }
`;

module.exports = { typeDefs };
