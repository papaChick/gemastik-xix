function deepMerge(target, source) {
    for (const key of Object.keys(source)) {
        if (
            source[key] &&
            typeof source[key] === "object" &&
            !Array.isArray(source[key])
        ) {
            if (!target[key] || typeof target[key] !== "object") {
                target[key] = {};
            }
            deepMerge(target[key], source[key]);
        } else {
            target[key] = source[key];
        }
    }
    return target;
}

const runtimeConfig = {
    theme: "light",
    locale: "id-ID",
    pdfEngine: "wkhtmltopdf",
};

function applyUserPrefs(userInput) {
    return deepMerge(runtimeConfig, userInput);
}

module.exports = { deepMerge, applyUserPrefs, runtimeConfig };
