function handleMetadataRequest(req, res) {
    if (req.path === "/latest/meta-data/") {
        return res.type("text/plain").send("iam/\ninternal-service-token\n");
    }
    if (req.path === "/latest/meta-data/iam/") {
        return res.type("text/plain").send("security-credentials/\n");
    }
    if (req.path === "/latest/meta-data/iam/security-credentials/") {
        return res.type("text/plain").send("tarot-club-ec2-role\n");
    }
    if (req.path === "/latest/meta-data/iam/security-credentials/tarot-club-ec2-role") {
        return res.type("application/json").send(JSON.stringify({
            Code: "Success",
            Type: "AWS-HMAC",
            AccessKeyId: "ASIAZZ7EXAMPLE7EXAMPLE",
            SecretAccessKey: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            Token: "FQoGZXIvYXdzEJr//////////wEaD" + "EXAMPLE".repeat(6),
            Expiration: "2099-01-01T00:00:00Z",
        }, null, 2));
    }
    if (req.path === "/latest/meta-data/internal-service-token") {
        return res
            .type("text/plain")
            .send(process.env.PHP_INTERNAL_TOKEN || "itk_devtoken_do_not_use_in_prod");
    }
    return res.status(404).send("not found");
}

module.exports = { handleMetadataRequest };
