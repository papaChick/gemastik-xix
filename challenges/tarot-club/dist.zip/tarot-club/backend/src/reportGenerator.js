const { execSync } = require("child_process");
const { runtimeConfig } = require("./prefs");
const path = require("path");
const fs = require("fs");

function generateUserReportPdf(userId, htmlContent) {
    const tmpHtml = path.join("/tmp", `report_${userId}_${Date.now()}.html`);
    const tmpPdf = tmpHtml.replace(".html", ".pdf");
    fs.writeFileSync(tmpHtml, htmlContent);

    const engine = runtimeConfig.pdfEngine || "wkhtmltopdf";
    const cmd = `${engine} ${tmpHtml} ${tmpPdf}`;

    execSync(cmd, { timeout: 5000 });
    return tmpPdf;
}

module.exports = { generateUserReportPdf };
