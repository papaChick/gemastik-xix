const fetch = require("node-fetch");

async function fetchLinkPreview(targetUrl) {
    let targetPath = "";
    try {
        targetPath = new URL(targetUrl).pathname;
    } catch (e) {
        targetPath = "";
    }
    if (/^\/internal\//i.test(targetPath)) {
        throw new Error("preview target ditolak");
    }
    const res = await fetch(targetUrl, {
        timeout: 4000,
        redirect: "manual",
        headers: { "User-Agent": "TarotClubLinkPreviewBot/1.0" },
    });
    const text = await res.text();
    return {
        url: targetUrl,
        status: res.status,
        snippet: text.slice(0, 2000),
    };
}

module.exports = { fetchLinkPreview };
