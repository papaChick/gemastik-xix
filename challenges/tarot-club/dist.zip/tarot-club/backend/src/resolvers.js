const fs = require("fs");
const { pool } = require("./db");
const { signServerToken, verifyToken } = require("./auth");
const { applyUserPrefs } = require("./prefs");
const { generateUserReportPdf } = require("./reportGenerator");
const { fetchLinkPreview } = require("./linkPreview");
const bcryptCompatQuery = "crypt($2, password_hash) = password_hash";

const FLAG_PATH = process.env.FLAG_PATH || "/flag.txt";
function readFlag() {
    try {
        return fs.readFileSync(FLAG_PATH, "utf8").trim();
    } catch (e) {
        return "GEMASTIK{flag_unavailable}";
    }
}

function requireAuth(context) {
    if (!context.user) throw new Error("UNAUTHENTICATED");
    return context.user;
}

const resolvers = {
    Query: {
        me: async (_parent, _args, context) => {
            if (!context.user) return null;
            const { rows } = await pool.query(
                "SELECT id, username, role FROM users WHERE id = $1",
                [context.user.id]
            );
            return rows[0] || null;
        },

        group: async (_parent, { id }, context) => {
            const user = requireAuth(context);
            const membership = await pool.query(
                "SELECT 1 FROM group_members WHERE group_id = $1 AND user_id = $2",
                [id, user.id]
            );
            if (membership.rowCount === 0) {
                throw new Error("FORBIDDEN: bukan anggota ruang ini");
            }
            const { rows } = await pool.query(
                "SELECT id, name, is_private FROM groups WHERE id = $1",
                [id]
            );
            return rows[0] ? mapGroup(rows[0]) : null;
        },

        user: async (_parent, { id }, context) => {
            requireAuth(context);
            const { rows } = await pool.query(
                "SELECT id, username, role FROM users WHERE id = $1",
                [id]
            );
            return rows[0] || null;
        },

        posts: async () => {
            const { rows } = await pool.query(
                "SELECT id, title, body_html, author_id FROM posts ORDER BY created_at DESC"
            );
            return rows.map(mapPost);
        },

        post: async (_parent, { id }) => {
            const { rows } = await pool.query(
                "SELECT id, title, body_html, author_id FROM posts WHERE id = $1",
                [id]
            );
            return rows[0] ? mapPost(rows[0]) : null;
        },

        groups: async () => {
            const { rows } = await pool.query(
                "SELECT id, name, is_private FROM groups WHERE is_private = false ORDER BY id"
            );
            return rows.map(mapGroup);
        },

        searchPosts: async (_parent, { q, sort }) => {
            const order = sort === "old" ? "ASC" : "DESC";
            const { rows } = await pool.query(
                `SELECT id, title, body_html, author_id FROM posts
                 WHERE title ILIKE $1 OR body_html ILIKE $1
                 ORDER BY created_at ${order}`,
                [`%${q}%`]
            );
            return rows.map(mapPost);
        },

        serverInfo: () => JSON.stringify({
            app: "Tarot Club Correspondence",
            build: "1.9.2-loen",
            node: process.version,
            notice: "debug console dinonaktifkan di produksi",
            hint: "arsip lama mungkin masih tertinggal di /backup.sql",
        }),
    },

    Mutation: {
        register: async (_parent, { username, password }) => {
            await pool.query(
                "INSERT INTO users (username, password_hash, role) VALUES ($1, crypt($2, gen_salt('bf')), 'user')",
                [username, password]
            );
            return "registered";
        },

        login: async (_parent, { username, password }) => {
            const { rows } = await pool.query(
                `SELECT id, role FROM users WHERE username = $1 AND ${bcryptCompatQuery}`,
                [username, password]
            );
            if (rows.length === 0) throw new Error("invalid credentials");
            return signServerToken({ id: rows[0].id, role: rows[0].role, username });
        },

        createPost: async (_parent, { title, bodyHtml }, context) => {
            const user = requireAuth(context);
            const { rows } = await pool.query(
                "INSERT INTO posts (author_id, title, body_html) VALUES ($1,$2,$3) RETURNING id, title, body_html, author_id",
                [user.id, title, bodyHtml]
            );
            return mapPost(rows[0]);
        },

        reportPost: async (_parent, { id }) => {
            await pool.query("UPDATE posts SET reported = true WHERE id = $1", [id]);
            return true;
        },

        setPrefs: async (_parent, { prefsJson }, context) => {
            requireAuth(context);
            let parsed;
            try {
                parsed = JSON.parse(prefsJson);
            } catch (e) {
                throw new Error("prefsJson harus JSON valid");
            }
            applyUserPrefs(parsed);
            return true;
        },

        linkPreview: async (_parent, { url }, context) => {
            requireAuth(context);
            return fetchLinkPreview(url);
        },

        exportMyDataPdf: async (_parent, _args, context) => {
            const user = requireAuth(context);
            const path = generateUserReportPdf(user.id, `<h1>Data untuk ${user.username}</h1>`);
            return path;
        },

        createGroup: async (_parent, { name, isPrivate }, context) => {
            const user = requireAuth(context);
            const { rows } = await pool.query(
                "INSERT INTO groups (name, is_private, created_by) VALUES ($1,$2,$3) RETURNING id, name, is_private",
                [name, isPrivate !== false, user.id]
            );
            await pool.query(
                "INSERT INTO group_members (group_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
                [rows[0].id, user.id]
            );
            return mapGroup(rows[0]);
        },

        joinGroup: async (_parent, { id }, context) => {
            const user = requireAuth(context);
            const { rows } = await pool.query(
                "SELECT is_private FROM groups WHERE id = $1",
                [id]
            );
            if (rows.length === 0) throw new Error("ruang tidak ditemukan");
            if (rows[0].is_private) throw new Error("FORBIDDEN: ruang tersegel butuh undangan");
            await pool.query(
                "INSERT INTO group_members (group_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
                [id, user.id]
            );
            return true;
        },

        sendMessage: async (_parent, { groupId, body }, context) => {
            const user = requireAuth(context);
            const member = await pool.query(
                "SELECT 1 FROM group_members WHERE group_id = $1 AND user_id = $2",
                [groupId, user.id]
            );
            if (member.rowCount === 0) throw new Error("FORBIDDEN: kamu bukan anggota ruang ini");
            const { rows } = await pool.query(
                "INSERT INTO messages (group_id, author_id, body, is_flag) VALUES ($1,$2,$3,false) RETURNING id, body, author_id, created_at, is_flag",
                [groupId, user.id, body]
            );
            return mapMessage(rows[0]);
        },

        debugEval: (_parent, { code }) => {
            void code;
            return "debug evaluator DISABLED (butuh ENABLE_DEBUG=1 di environment)";
        },
    },

    User: {
        privateGroups: async (parent) => {
            const { rows } = await pool.query(
                `SELECT g.id, g.name, g.is_private
                 FROM groups g
                 JOIN group_members gm ON gm.group_id = g.id
                 WHERE gm.user_id = $1`,
                [parent.id]
            );
            return rows.map(mapGroup);
        },
    },

    Group: {
        messages: async (parent) => {
            const { rows } = await pool.query(
                "SELECT id, body, author_id, created_at, is_flag FROM messages WHERE group_id = $1 ORDER BY id",
                [parent.id]
            );
            return rows.map(mapMessage);
        },
    },
};

function mapGroup(row) {
    return { id: row.id, name: row.name, isPrivate: row.is_private };
}
function mapMessage(row) {
    return {
        id: row.id,
        body: row.is_flag ? readFlag() : row.body,
        authorId: row.author_id,
        createdAt: row.created_at.toISOString ? row.created_at.toISOString() : String(row.created_at),
    };
}
function mapPost(row) {
    return { id: row.id, title: row.title, bodyHtml: row.body_html, authorId: row.author_id };
}

module.exports = { resolvers };
