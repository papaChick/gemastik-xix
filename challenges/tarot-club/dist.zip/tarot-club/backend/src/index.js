const express = require("express");
const cookieParser = require("cookie-parser");
const { ApolloServer } = require("apollo-server-express");
const { typeDefs } = require("./schema");
const { resolvers } = require("./resolvers");
const { verifyToken, signServerToken } = require("./auth");
const { handleMetadataRequest } = require("./metadataSim");
const { pool } = require("./db");
const { buildSignedSamlResponse, verifySamlAndExtract } = require("./saml");
const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");
const { redis } = require("./redisClient");

const FLAG_PATH = process.env.FLAG_PATH || "/flag.txt";
function readFlag() {
    try {
        return fs.readFileSync(FLAG_PATH, "utf8").trim();
    } catch (e) {
        return "GEMASTIK{flag_unavailable}";
    }
}

async function main() {
    const app = express();
    app.use(express.json());
    app.use(cookieParser());

    app.get("/latest/meta-data*", handleMetadataRequest);

    app.get("/health", (_req, res) => res.json({ status: "ok" }));

    app.get("/api/flag", (_req, res) => {
        res.status(418).type("text/plain").send(
            "Sayang sekali — flag tidak pernah disajikan lewat HTTP langsung. " +
            "Teruslah mencari. ☕ (FLAG{ini_cuma_umpan_bukan_flag_asli})"
        );
    });

    app.get("/api/debug/env", (req, res) => {
        const t = req.query.token || "";
        if (!["dev", "debug", "changeme"].includes(String(t))) {
            return res.status(403).type("text/plain").send(
                "forbidden — butuh ?token=<dev token>"
            );
        }
        res.type("application/json").send(JSON.stringify({
            NODE_ENV: "production",
            DATABASE_URL: "postgres://app:app@db.internal:5432/app",
            JWT_SECRET: "dev-secret-change-me-before-prod",
            ADMIN_BACKDOOR: "disabled",
            note: "arsip SQL lama konon masih ada di /backup.sql",
        }, null, 2));
    });

    app.all("/api/login-legacy", (_req, res) => {
        res.status(410).type("text/plain").send(
            "endpoint login lama sudah dimatikan; migrasi ke SSO."
        );
    });

    app.post("/api/saml/idp/login", async (req, res) => {
        const { username, password } = req.body || {};
        if (!username || !password) {
            return res.status(400).json({ error: "username & password wajib" });
        }
        const { rows } = await pool.query(
            "SELECT id, role FROM users WHERE username = $1 AND crypt($2, password_hash) = password_hash",
            [username, password]
        );
        if (rows.length === 0) {
            return res.status(401).json({ error: "kredensial salah" });
        }
        if (rows[0].role === "admin") {
            return res.status(403).json({ error: "akun tinggi memakai token perangkat keras, bukan SSO" });
        }
        const xml = buildSignedSamlResponse(username, rows[0].role);
        res.json({ SAMLResponse: Buffer.from(xml, "utf8").toString("base64") });
    });

    app.post("/api/saml/acs", async (req, res) => {
        const b64 = (req.body && req.body.SAMLResponse) || "";
        let claims;
        try {
            const xml = Buffer.from(String(b64), "base64").toString("utf8");
            claims = verifySamlAndExtract(xml);
        } catch (e) {
            return res.status(401).json({ error: "SAML Response ditolak: " + e.message });
        }
        const { rows } = await pool.query(
            "SELECT id FROM users WHERE username = $1",
            [claims.username]
        );
        const id = rows[0] ? rows[0].id : 0;
        const token = signServerToken({ id, role: claims.role, username: claims.username });
        res.json({ token, username: claims.username, role: claims.role });
    });

    app.get("/internal/admin/ops-flag", (_req, res) => {
        res.type("text/plain").send(readFlag());
    });

    app.get("/api/admin/secret", async (req, res) => {
        const authHeader = req.headers.authorization || "";
        const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
        if (!token) return res.status(401).json({ error: "unauthenticated" });
        let claims;
        try {
            claims = verifyToken(token);
        } catch (e) {
            return res.status(401).json({ error: "invalid token" });
        }
        if (claims.role !== "admin") {
            return res.status(403).json({ error: "forbidden" });
        }
        res.type("text/plain").send(readFlag());
    });

    app.get("/api/reports/:name", (req, res) => {
        const safeName = path.basename(req.params.name);
        const filePath = path.join("/tmp", safeName);
        if (!fs.existsSync(filePath)) return res.status(404).send("not found");
        res.sendFile(filePath);
    });

    const apollo = new ApolloServer({
        typeDefs,
        resolvers,
        context: ({ req }) => {
            let user = null;
            const authHeader = req.headers.authorization || "";
            const token = authHeader.startsWith("Bearer ")
                ? authHeader.slice(7)
                : req.cookies && req.cookies.token;

            if (token) {
                try {
                    user = verifyToken(token);
                } catch (e) {
                    user = null;
                }
            }
            return { user };
        },
    });

    await apollo.start();
    apollo.applyMiddleware({ app, path: "/graphql" });

    app.post("/api/avatar", express.json(), async (req, res) => {
        try {
            const internalToken =
                process.env.PHP_INTERNAL_TOKEN || "itk_devtoken_do_not_use_in_prod";
            const r = await fetch(`${process.env.PHP_INTERNAL_URL}/avatar.php`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Internal-Token": internalToken,
                },
                body: JSON.stringify({ avatarConfig: req.body.avatarConfig }),
            });
            const text = await r.text();
            res.status(r.status).send(text);
        } catch (e) {
            res.status(502).json({ error: "avatar service unreachable" });
        }
    });

    app.use(express.static("public"));

    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => {
        console.log(`Tarot Club backend listening on :${PORT}`);
        console.log(`GraphQL endpoint: ${apollo.graphqlPath}`);
    });
}

main().catch((e) => {
    console.error("fatal startup error", e);
    process.exit(1);
});
