const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");

const KEYS_DIR = process.env.JWT_KEYS_DIR || "/app/keys";
const DEFAULT_KID = "server.key";

function signServerToken(payload) {
    const secret = fs.readFileSync(path.join(KEYS_DIR, DEFAULT_KID), "utf8");
    return jwt.sign(payload, secret, {
        algorithm: "HS256",
        header: { kid: DEFAULT_KID },
        expiresIn: "2h",
    });
}

function verifyToken(token) {
    const decodedHeader = jwt.decode(token, { complete: true });
    if (!decodedHeader || !decodedHeader.header || !decodedHeader.header.kid) {
        throw new Error("token tanpa kid ditolak");
    }

    const kid = decodedHeader.header.kid;
    const keyPath = path.join(KEYS_DIR, kid);

    let secretMaterial;
    try {
        secretMaterial = fs.readFileSync(keyPath, "utf8");
    } catch (e) {
        throw new Error("kid tidak valid");
    }

    return jwt.verify(token, secretMaterial);
}

module.exports = { signServerToken, verifyToken, KEYS_DIR, DEFAULT_KID };
