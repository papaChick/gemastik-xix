const fs = require("fs");
const crypto = require("crypto");
const { SignedXml } = require("xml-crypto");
const { DOMParser } = require("@xmldom/xmldom");
const xpath = require("xpath");

const IDP_KEY_PATH = process.env.SAML_IDP_KEY || "/app/backend/keys/idp_private.pem";
const IDP_CERT_PATH = process.env.SAML_IDP_CERT || "/app/backend/keys/idp_cert.pem";
const ISSUER = "https://idp.tarot.loen/metadata";

const NS_SAMLP = "urn:oasis:names:tc:SAML:2.0:protocol";
const NS_SAML = "urn:oasis:names:tc:SAML:2.0:assertion";

function idpKey() {
    return fs.readFileSync(IDP_KEY_PATH, "utf8");
}
function idpCert() {
    return fs.readFileSync(IDP_CERT_PATH, "utf8");
}

function buildSignedSamlResponse(username, role) {
    const rid = "_" + crypto.randomBytes(16).toString("hex");
    const aid = "_" + crypto.randomBytes(16).toString("hex");
    const now = new Date().toISOString();

    const xml =
        `<samlp:Response xmlns:samlp="${NS_SAMLP}" ID="${rid}" Version="2.0" IssueInstant="${now}">` +
        `<saml:Issuer xmlns:saml="${NS_SAML}">${ISSUER}</saml:Issuer>` +
        `<saml:Assertion xmlns:saml="${NS_SAML}" ID="${aid}" Version="2.0" IssueInstant="${now}">` +
        `<saml:Issuer>${ISSUER}</saml:Issuer>` +
        `<saml:Subject><saml:NameID>${username}</saml:NameID></saml:Subject>` +
        `<saml:AttributeStatement>` +
        `<saml:Attribute Name="role"><saml:AttributeValue>${role}</saml:AttributeValue></saml:Attribute>` +
        `</saml:AttributeStatement>` +
        `</saml:Assertion>` +
        `</samlp:Response>`;

    const sig = new SignedXml({
        privateKey: idpKey(),
        signatureAlgorithm: "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256",
        canonicalizationAlgorithm: "http://www.w3.org/2001/10/xml-exc-c14n#",
    });
    sig.addReference({
        xpath: "//*[local-name(.)='Assertion']",
        transforms: [
            "http://www.w3.org/2000/09/xmldsig#enveloped-signature",
            "http://www.w3.org/2001/10/xml-exc-c14n#",
        ],
        digestAlgorithm: "http://www.w3.org/2001/04/xmlenc#sha256",
    });
    sig.computeSignature(xml, {
        location: { reference: "//*[local-name(.)='Assertion']", action: "append" },
    });
    return sig.getSignedXml();
}

function verifySamlAndExtract(xml) {
    const doc = new DOMParser().parseFromString(xml, "text/xml");

    const sigNodes = xpath.select(
        "//*[local-name(.)='Signature' and namespace-uri(.)='http://www.w3.org/2000/09/xmldsig#']",
        doc
    );
    if (!sigNodes.length) throw new Error("tidak ada signature");

    const sig = new SignedXml({ publicCert: idpCert() });
    sig.loadSignature(sigNodes[0]);
    const valid = sig.checkSignature(xml);
    if (!valid) throw new Error("signature tidak valid");

    const assertions = xpath.select("//*[local-name(.)='Assertion']", doc);
    if (!assertions.length) throw new Error("tidak ada assertion");
    const a = assertions[0];

    const nameId = xpath.select("string(.//*[local-name(.)='NameID'])", a);
    const role = xpath.select(
        "string(.//*[local-name(.)='Attribute'][@Name='role']/*[local-name(.)='AttributeValue'])",
        a
    );
    return { username: String(nameId).trim(), role: String(role).trim() || "user" };
}

module.exports = { buildSignedSamlResponse, verifySamlAndExtract, ISSUER };
