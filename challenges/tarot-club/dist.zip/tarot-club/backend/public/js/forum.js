cbRenderNav("forum");

const notice = document.getElementById("notice");

async function createPost() {
    const title = document.getElementById("title").value;
    const body = document.getElementById("body").value;

    if (!cbGetToken()) {
        cbNotice(notice, "!! Kamu harus masuk ke Perkumpulan dulu sebelum menulis surat.", "err");
        return;
    }
    if (!title || !body) {
        cbNotice(notice, "!! Perihal dan isi surat tidak boleh kosong.", "err");
        return;
    }

    const r = await gql(
        `mutation($t:String!,$b:String!){ createPost(title:$t, bodyHtml:$b){ id title bodyHtml authorId } }`,
        { t: title, b: body }
    );
    if (r.errors) {
        cbNotice(notice, ">> Gagal mengirim surat: " + r.errors[0].message, "err");
        return;
    }
    cbNotice(notice, `>> Surat "${r.data.createPost.title}" berhasil disegel dan dikirim.`, "ok");
    document.getElementById("title").value = "";
    document.getElementById("body").value = "";
    loadPosts();
}

async function reportPost(id) {
    const r = await gql(`mutation($id:ID!){ reportPost(id:$id) }`, { id });
    if (r.errors) {
        cbNotice(notice, ">> Gagal melaporkan surat: " + r.errors[0].message, "err");
        return;
    }
    cbNotice(notice, `>> Surat #${id} telah dilaporkan ke penjaga arsip.`, "ok");
}

async function previewLink() {
    const url = document.getElementById("preview-url").value;
    const out = document.getElementById("preview-result");
    if (!cbGetToken()) {
        out.innerHTML = `<p class="muted">Masuk dulu untuk meninjau tautan.</p>`;
        return;
    }
    if (!url) return;
    out.innerHTML = `<p class="muted">Mengintai kabut...</p>`;
    const r = await gql(`mutation($u:String!){ linkPreview(url:$u){ url status snippet } }`, { u: url });
    if (r.errors) {
        out.innerHTML = `<p class="muted">Gagal meninjau: ${escapeHtml(r.errors[0].message)}</p>`;
        return;
    }
    const p = r.data.linkPreview;
    out.innerHTML = `
        <div class="notice-bar" style="display:block;">
            <b>${p.status}</b> &mdash; ${escapeHtml(p.url)}
            <pre>${escapeHtml(p.snippet)}</pre>
        </div>
    `;
}

async function loadPosts() {
    const container = document.getElementById("post-list");
    const r = await gql(`query{ posts{ id title bodyHtml authorId } }`);
    if (r.errors || !r.data) {
        container.innerHTML = `<p style="color:var(--c-danger);">Gagal memuat surat-surat.</p>`;
        return;
    }
    const posts = r.data.posts;
    document.getElementById("stat-topics").textContent = posts.length;

    if (posts.length === 0) {
        container.innerHTML = `<p class="muted" style="font-style:italic;">Belum ada surat. Jadilah pengirim pertama.</p>`;
        return;
    }

    container.innerHTML = "";
    posts.forEach((post) => container.appendChild(renderPostBox(post)));
}

function renderPostBox(post) {
    const box = document.createElement("div");
    box.className = "post-box";

    const avatar = document.createElement("div");
    avatar.className = "post-avatar";
    avatar.textContent = `#${post.authorId}`;

    const main = document.createElement("div");
    main.className = "post-main";

    const meta = document.createElement("div");
    meta.className = "post-meta";
    meta.innerHTML = `
        <a class="post-author" href="/profile.html?id=${post.authorId}">anggota_${post.authorId}</a>
        <span class="post-role">SURAT #${post.id}</span>
    `;

    const titleEl = document.createElement("div");
    titleEl.className = "post-title";
    titleEl.textContent = post.title;

    const bodyEl = document.createElement("div");
    bodyEl.className = "post-body";
    renderPostSafely(bodyEl, post.bodyHtml);

    const actions = document.createElement("div");
    actions.className = "post-actions";
    actions.innerHTML = `<a href="#post-panel">&#8617; Balas</a><a href="javascript:void(0)" onclick="reportPost('${post.id}')">&#9873; Laporkan</a>`;

    main.appendChild(meta);
    main.appendChild(titleEl);
    main.appendChild(bodyEl);
    main.appendChild(actions);

    box.appendChild(avatar);
    box.appendChild(main);
    return box;
}

function renderPostSafely(container, html) {
    const allowed = new Set(["B", "I", "EM", "STRONG", "P", "BR", "UL", "LI", "A"]);
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    (function clean(node) {
        [...node.children].forEach((child) => {
            if (!allowed.has(child.tagName)) {
                child.replaceWith(...child.childNodes);
                return;
            }
            [...child.attributes].forEach((attr) => {
                const isSafeHref =
                    child.tagName === "A" &&
                    attr.name === "href" &&
                    /^https?:\/\//i.test(attr.value);
                if (!isSafeHref) child.removeAttribute(attr.name);
            });
            clean(child);
        });
    })(tmp);
    container.innerHTML = "";
    container.appendChild(tmp);
}

function renderHitCounter() {
    const el = document.getElementById("hit-counter");
    const base = 133742 + (Math.floor(Date.now() / 100000) % 900);
    el.textContent = String(base).padStart(6, "0");
}

document.getElementById("post-form").addEventListener("submit", (e) => {
    e.preventDefault();
    createPost();
});
document.getElementById("preview-btn").addEventListener("click", previewLink);

renderHitCounter();
loadPosts();
