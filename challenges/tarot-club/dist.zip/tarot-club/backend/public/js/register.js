cbRenderNav("register");

document.getElementById("register-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const notice = document.getElementById("notice");

    const r = await gql(
        `mutation($u:String!,$p:String!){ register(username:$u, password:$p) }`,
        { u: username, p: password }
    );

    if (r.errors) {
        cbNotice(notice, ">> Permohonan ditolak: " + r.errors[0].message, "err");
        return;
    }

    cbNotice(notice, ">> Permohonan diterima. Mengarahkan ke gerbang masuk...", "ok");
    setTimeout(() => (window.location.href = "/login.html"), 700);
});
