cbRenderNav("search");

const notice = document.getElementById("notice");

async function runSearch(q, sort) {
    const results = document.getElementById("results");
    results.innerHTML = `<p class="muted">Menelusuri arsip...</p>`;
    const r = await gql(
        `query($q:String!,$s:String){ searchPosts(q:$q, sort:$s){ id title bodyHtml authorId } }`,
        { q, s: sort }
    );
    if (r.errors) {
        cbNotice(notice, ">> Pencarian gagal: " + r.errors[0].message, "err");
        results.innerHTML = "";
        return;
    }
    const posts = r.data.searchPosts || [];
    if (posts.length === 0) {
        results.innerHTML = `<p class="muted">Tidak ada surat yang cocok.</p>`;
        return;
    }
    results.innerHTML = posts
        .map(
            (p) => `
            <div class="post-box">
                <div class="post-avatar">#${p.authorId}</div>
                <div class="post-main">
                    <div class="post-meta">
                        <a class="post-author" href="/profile.html?id=${p.authorId}">anggota_${p.authorId}</a>
                        <span class="post-role">SURAT #${p.id}</span>
                    </div>
                    <div class="post-title">${escapeHtml(p.title)}</div>
                </div>
            </div>
        `
        )
        .join("");
}

document.getElementById("search-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = document.getElementById("q").value;
    const sort = document.getElementById("sort").value;
    runSearch(q, sort);
});

(function init() {
    if (!cbRequireAuth()) return;
    runSearch("", "new");
})();
