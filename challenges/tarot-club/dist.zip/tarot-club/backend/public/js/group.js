cbRenderNav("groups");

const notice = document.getElementById("notice");
let currentGroupId = null;

async function loadGroup(id) {
    const r = await gql(
        `query($id:ID!){ group(id:$id){ id name isPrivate messages{ id body authorId createdAt } } }`,
        { id: String(id) }
    );

    if (r.errors) {
        cbNotice(notice, ">> Pintu tertutup: " + r.errors[0].message, "err");
        return;
    }
    if (!r.data.group) {
        cbNotice(notice, ">> Ruang tidak ditemukan.", "err");
        return;
    }

    const g = r.data.group;
    document.getElementById("group-name").textContent = g.name;
    document.getElementById("compose-card").style.display = "block";

    const list = document.getElementById("message-list");
    if (!g.messages || g.messages.length === 0) {
        list.innerHTML = `<p class="muted">Ruang ini masih kosong.</p>`;
        return;
    }
    list.innerHTML = g.messages
        .map(
            (m) => `
            <div class="post-box">
                <div class="post-avatar">#${m.authorId}</div>
                <div class="post-main">
                    <div class="post-body">${escapeHtml(m.body)}</div>
                    <div class="post-meta">${escapeHtml(m.createdAt)}</div>
                </div>
            </div>
        `
        )
        .join("");
}

document.getElementById("send-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const body = document.getElementById("msg-body").value.trim();
    if (!body || !currentGroupId) return;
    const r = await gql(
        `mutation($g:ID!,$b:String!){ sendMessage(groupId:$g, body:$b){ id } }`,
        { g: String(currentGroupId), b: body }
    );
    if (r.errors) {
        cbNotice(notice, ">> Gagal mengirim: " + r.errors[0].message, "err");
        return;
    }
    document.getElementById("msg-body").value = "";
    cbNotice(notice, ">> Pesan terkirim.", "ok");
    loadGroup(currentGroupId);
});

(function init() {
    if (!cbRequireAuth()) return;
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    if (!id) {
        cbNotice(notice, ">> Nomor ruang tidak diketahui.", "err");
        return;
    }
    currentGroupId = id;
    loadGroup(id);
})();
