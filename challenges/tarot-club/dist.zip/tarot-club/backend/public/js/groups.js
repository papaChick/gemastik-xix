cbRenderNav("groups");

const notice = document.getElementById("notice");

async function loadMyGroups() {
    const r = await gql(`query{ me{ privateGroups{ id name isPrivate } } }`);
    const list = document.getElementById("group-list");

    if (r.errors || !r.data || !r.data.me) {
        cbNotice(notice, ">> Gagal memuat ruang: " + (r.errors ? r.errors[0].message : "sesi tidak valid"), "err");
        return;
    }

    const groups = r.data.me.privateGroups || [];
    if (groups.length === 0) {
        list.innerHTML = `<p class="muted">Kamu belum menjadi anggota ruang mana pun.</p>`;
        return;
    }

    list.innerHTML = groups
        .map(
            (g) => `
            <div class="post-box">
                <div class="post-avatar">${g.isPrivate ? "&#128274;" : "&#127777;"}</div>
                <div class="post-main">
                    <div class="post-title">${escapeHtml(g.name)}</div>
                    <div class="post-body muted">${g.isPrivate ? "Ruang tersegel &mdash; hanya anggota" : "Ruang terbuka"}</div>
                    <div class="post-actions">
                        <a href="/group.html?id=${g.id}">&#8594; Masuk ke ruang ini</a>
                    </div>
                </div>
            </div>
        `
        )
        .join("");
}

async function loadDiscover() {
    const r = await gql(`query{ groups{ id name isPrivate } }`);
    const list = document.getElementById("discover-list");
    if (r.errors || !r.data) {
        list.innerHTML = `<p class="muted">Gagal memuat ruang umum.</p>`;
        return;
    }
    const groups = r.data.groups || [];
    if (groups.length === 0) {
        list.innerHTML = `<p class="muted">Belum ada ruang umum.</p>`;
        return;
    }
    list.innerHTML = groups
        .map(
            (g) => `
            <div class="post-box">
                <div class="post-avatar">&#127777;</div>
                <div class="post-main">
                    <div class="post-title">${escapeHtml(g.name)}</div>
                    <div class="post-actions">
                        <a href="/group.html?id=${g.id}">&#8594; Lihat</a>
                        <a href="javascript:void(0)" onclick="joinGroup('${g.id}')">&#10022; Gabung</a>
                    </div>
                </div>
            </div>
        `
        )
        .join("");
}

async function joinGroup(id) {
    const r = await gql(`mutation($id:ID!){ joinGroup(id:$id) }`, { id: String(id) });
    if (r.errors) {
        cbNotice(notice, ">> Gagal gabung: " + r.errors[0].message, "err");
        return;
    }
    cbNotice(notice, ">> Berhasil bergabung ke ruang.", "ok");
    loadMyGroups();
}

document.getElementById("create-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("new-name").value.trim();
    const isPrivate = document.getElementById("new-private").checked;
    if (!name) return;
    const r = await gql(
        `mutation($n:String!,$p:Boolean){ createGroup(name:$n, isPrivate:$p){ id } }`,
        { n: name, p: isPrivate }
    );
    if (r.errors) {
        cbNotice(notice, ">> Gagal mendirikan ruang: " + r.errors[0].message, "err");
        return;
    }
    cbNotice(notice, ">> Ruang didirikan.", "ok");
    document.getElementById("new-name").value = "";
    loadMyGroups();
    loadDiscover();
});

(async function init() {
    if (!cbRequireAuth()) return;
    loadMyGroups();
    loadDiscover();
})();
