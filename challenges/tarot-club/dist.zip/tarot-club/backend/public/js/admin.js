cbRenderNav("admin");

const notice = document.getElementById("notice");

document.getElementById("open-btn").addEventListener("click", async () => {
    const resultEl = document.getElementById("admin-result");
    const token = cbGetToken();
    if (!token) {
        cbNotice(notice, "!! Kamu belum membawa token keanggotaan apa pun.", "err");
        return;
    }

    const res = await fetch("/api/admin/secret", {
        headers: { Authorization: `Bearer ${token}` },
    });
    const text = await res.text();

    resultEl.style.display = "block";
    resultEl.textContent = text;

    if (res.ok) {
        cbNotice(notice, ">> Pintu terbuka.", "ok");
    } else {
        cbNotice(notice, `>> Ditolak (${res.status}) &mdash; token ini bukan milik Sequence 0.`, "err");
    }
});

(function init() {
    cbRequireAuth();
})();
