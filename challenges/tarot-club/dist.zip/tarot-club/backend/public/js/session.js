const CB_TOKEN_KEY = "cb_token";

function cbGetToken() {
    return localStorage.getItem(CB_TOKEN_KEY);
}

function cbSetToken(token) {
    localStorage.setItem(CB_TOKEN_KEY, token);
}

function cbClearToken() {
    localStorage.removeItem(CB_TOKEN_KEY);
}

async function gql(query, variables) {
    const token = cbGetToken();
    const res = await fetch("/graphql", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ query, variables: variables || {} }),
    });
    return res.json();
}

let _cbMeCache = null;
async function cbCurrentUser(forceRefresh) {
    if (_cbMeCache && !forceRefresh) return _cbMeCache;
    if (!cbGetToken()) return null;
    const r = await gql(`query{ me{ id username role } }`);
    _cbMeCache = (r.data && r.data.me) || null;
    return _cbMeCache;
}

function cbLogout() {
    cbClearToken();
    _cbMeCache = null;
    window.location.href = "/login.html";
}

function cbRequireAuth() {
    if (!cbGetToken()) {
        window.location.href = "/login.html";
        return false;
    }
    return true;
}

function cbNotice(el, msg, type) {
    if (!el) return;
    el.textContent = msg;
    el.className = "notice-bar" + (type ? " " + type : "");
}

const CB_NAV_ITEMS = [
    { href: "/index.html", label: "Ruang Baca", key: "forum" },
    { href: "/sso.html", label: "SSO", key: "sso" },
    { href: "/search.html", label: "Cari Surat", key: "search" },
    { href: "/groups.html", label: "Ruang", key: "groups" },
    { href: "/settings.html", label: "Preferensi", key: "settings" },
    { href: "/avatar.html", label: "Lambang", key: "avatar" },
    { href: "/admin.html", label: "Ruang Tinggi", key: "admin" },
];

async function cbRenderNav(activeKey) {
    const mount = document.getElementById("site-nav");
    if (!mount) return;

    const token = cbGetToken();
    const user = token ? await cbCurrentUser() : null;

    const links = CB_NAV_ITEMS.map(
        (item) =>
            `<a href="${item.href}" class="${item.key === activeKey ? "active" : ""}">${item.label}</a>`
    ).join("");

    const authArea = user
        ? `<a href="/profile.html?id=${user.id}" class="${activeKey === "profile" ? "active" : ""}">Berkasku</a>
           <span class="nav-user">${escapeHtml(user.username)}<span class="role-badge">${escapeHtml(user.role)}</span></span>
           <button class="linklike" id="cb-logout-btn">Tinggalkan Perkumpulan</button>`
        : `<a href="/login.html" class="${activeKey === "login" ? "active" : ""}">Masuk</a>
           <a href="/register.html" class="${activeKey === "register" ? "active" : ""}">Daftar</a>`;

    mount.innerHTML = `
        <header class="masthead">
            <div class="brand">
                <span class="glyph">&#10022;</span>
                <div>
                    <h1>Tarot Club</h1>
                    <span class="tagline">Wadah Korespondensi Tersegel &mdash; Kota Loen</span>
                </div>
            </div>
            <nav class="nav-links">
                ${links}
                ${authArea}
            </nav>
        </header>
    `;

    const logoutBtn = document.getElementById("cb-logout-btn");
    if (logoutBtn) logoutBtn.addEventListener("click", cbLogout);
}

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = String(str);
    return div.innerHTML;
}
