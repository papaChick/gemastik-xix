cbRenderNav("avatar");

const notice = document.getElementById("notice");

document.getElementById("avatar-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const raw = document.getElementById("avatar-json").value;
    const resultEl = document.getElementById("avatar-result");

    let avatarConfig;
    try {
        avatarConfig = JSON.parse(raw);
    } catch (err) {
        cbNotice(notice, "!! Konfigurasi harus JSON yang valid.", "err");
        return;
    }

    try {
        const res = await fetch("/api/avatar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ avatarConfig }),
        });
        const text = await res.text();
        resultEl.style.display = "block";
        resultEl.textContent = text;
        cbNotice(
            notice,
            res.ok ? ">> Lambang diperbarui." : ">> Layanan menolak permintaan (" + res.status + ").",
            res.ok ? "ok" : "err"
        );
    } catch (err) {
        cbNotice(notice, ">> Layanan lambang tidak tersedia.", "err");
    }
});

(function init() {
    cbRequireAuth();
})();
