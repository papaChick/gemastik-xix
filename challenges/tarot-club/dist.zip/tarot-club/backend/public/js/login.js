cbRenderNav("login");

document.getElementById("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const notice = document.getElementById("notice");

    const r = await gql(
        `mutation($u:String!,$p:String!){ login(username:$u, password:$p) }`,
        { u: username, p: password }
    );

    if (r.errors) {
        cbNotice(notice, ">> Gagal masuk: " + r.errors[0].message, "err");
        return;
    }

    cbSetToken(r.data.login);
    cbNotice(notice, `>> Selamat datang kembali, ${username}. Membuka gerbang Ruang Baca...`, "ok");
    setTimeout(() => (window.location.href = "/index.html"), 500);
});
