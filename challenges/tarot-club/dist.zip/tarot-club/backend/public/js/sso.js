cbRenderNav("sso");

const notice = document.getElementById("notice");

document.getElementById("sso-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    let idp;
    try {
        const r = await fetch("/api/saml/idp/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password }),
        });
        idp = await r.json();
        if (!r.ok) throw new Error(idp.error || "gagal");
    } catch (err) {
        cbNotice(notice, ">> IdP menolak: " + err.message, "err");
        return;
    }

    try {
        const r = await fetch("/api/saml/acs", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ SAMLResponse: idp.SAMLResponse }),
        });
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || "gagal");
        cbSetToken(data.token);
        cbNotice(notice, `>> Segel diterima. Masuk sebagai ${data.username} (${data.role}).`, "ok");
        setTimeout(() => (window.location.href = "/index.html"), 600);
    } catch (err) {
        cbNotice(notice, ">> ACS menolak: " + err.message, "err");
    }
});
