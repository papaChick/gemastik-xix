cbRenderNav("settings");

const notice = document.getElementById("notice");

document.getElementById("prefs-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const raw = document.getElementById("prefs-json").value;

    const r = await gql(`mutation($p:String!){ setPrefs(prefsJson:$p) }`, { p: raw });
    if (r.errors) {
        cbNotice(notice, ">> Gagal menyimpan preferensi: " + r.errors[0].message, "err");
        return;
    }
    cbNotice(notice, ">> Preferensi tersimpan.", "ok");
});

document.getElementById("export-btn").addEventListener("click", async () => {
    const out = document.getElementById("export-result");
    out.innerHTML = `<p class="muted">Menyusun berkas...</p>`;

    const r = await gql(`mutation{ exportMyDataPdf }`);
    if (r.errors) {
        out.innerHTML = `<p style="color:var(--c-danger);">Gagal: ${escapeHtml(r.errors[0].message)}</p>`;
        return;
    }
    const fullPath = r.data.exportMyDataPdf;
    const name = fullPath.split(/[\\/]/).pop();
    out.innerHTML = `<p class="notice-bar ok" style="display:block;">Berkas siap: <a href="/api/reports/${encodeURIComponent(name)}" target="_blank">${escapeHtml(name)}</a></p>`;
});

(function init() {
    cbRequireAuth();
})();
