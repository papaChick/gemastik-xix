cbRenderNav("profile");

const notice = document.getElementById("notice");

async function lookupUser(id) {
    if (!id) return;
    const r = await gql(
        `query($id:ID!){
            user(id:$id) {
                id
                username
                role
                privateGroups {
                    id
                    name
                    isPrivate
                    messages { id body authorId createdAt }
                }
            }
        }`,
        { id: String(id) }
    );

    if (r.errors) {
        cbNotice(notice, ">> Berkas tidak ditemukan atau ditolak: " + r.errors[0].message, "err");
        document.getElementById("dossier-card").style.display = "none";
        return;
    }
    if (!r.data.user) {
        cbNotice(notice, ">> Tidak ada berkas dengan nomor tersebut.", "err");
        document.getElementById("dossier-card").style.display = "none";
        return;
    }

    cbNotice(notice, "", "empty");
    renderDossier(r.data.user);
}

function renderDossier(user) {
    document.getElementById("dossier-card").style.display = "block";
    document.getElementById("dossier-sigil").textContent = user.username.slice(0, 1).toUpperCase();
    document.getElementById("dossier-name").textContent = `${user.username} — Berkas #${user.id}`;
    document.getElementById("dossier-role").textContent =
        user.role === "admin" ? "Sequence 0 · Pemimpin Perkumpulan" : "Sequence 9 · Pencari";

    const groupsEl = document.getElementById("dossier-groups");
    if (!user.privateGroups || user.privateGroups.length === 0) {
        groupsEl.innerHTML = `<p class="muted">Tidak ada ruang tersegel tercatat pada berkas ini.</p>`;
        return;
    }

    groupsEl.innerHTML = user.privateGroups
        .map((g) => {
            const msgs = (g.messages || [])
                .map(
                    (m) => `
                        <div class="msg-line">
                            ${escapeHtml(m.body)}
                            <div class="msg-meta">anggota #${m.authorId} &middot; ${escapeHtml(m.createdAt)}</div>
                        </div>`
                )
                .join("");
            return `
                <div class="sealed-room">
                    <h3>&#128274; ${escapeHtml(g.name)} ${g.isPrivate ? '<span class="pill">tersegel</span>' : ""}</h3>
                    ${msgs || '<p class="muted">Ruang ini kosong.</p>'}
                </div>
            `;
        })
        .join("");
}

document.getElementById("lookup-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const id = document.getElementById("lookup-id").value.trim();
    lookupUser(id);
});

(async function init() {
    if (!cbRequireAuth()) return;
    const params = new URLSearchParams(window.location.search);
    let id = params.get("id");
    if (!id) {
        const me = await cbCurrentUser();
        id = me ? me.id : null;
    }
    if (id) {
        document.getElementById("lookup-id").value = id;
        lookupUser(id);
    }
})();
