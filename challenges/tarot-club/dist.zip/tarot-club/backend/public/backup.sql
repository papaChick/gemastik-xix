CREATE TABLE users (id INT, username TEXT, password_hash TEXT, role TEXT);
INSERT INTO users VALUES (1,'admin','$2b$10$u1Qk9Z3nYfRq2pL7sVeJ8eWnO4cF6dRtH0aXbYcZdEfGhIjKlMnO','admin');
INSERT INTO users VALUES (2,'alice','$2b$10$K3mP8rT1sV6wX9yA2bC4dOqE5fG7hI9jK0lM1nO2pQ3rS4tU5vW6','user');

CREATE TABLE secrets (k TEXT, v TEXT);
INSERT INTO secrets VALUES ('legacy_jwt_secret','dev-secret-change-me-before-prod');
INSERT INTO secrets VALUES ('archived_flag','FLAG{arsip_lama_sudah_lama_dirotasi}');
