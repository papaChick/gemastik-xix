#!/bin/bash
PGBIN="$(ls -d /usr/lib/postgresql/*/bin | head -1)"
exec gosu postgres "$PGBIN/postgres" -D /var/lib/postgresql/data \
    -c listen_addresses=127.0.0.1 -c port=5432
