# Tarot Club

Aplikasi korespondensi tersegel bergaya perkumpulan rahasia kota Loen: forum
("Ruang Baca") publik + ruang-ruang chat tersegel antar-anggota.

Satu layanan, satu kontainer. Di dalamnya `supervisord` menjalankan:

- **nginx** — satu-satunya entrypoint publik (port layanan), menyajikan frontend
  statis dan mem-proxy `/graphql` serta `/api/`.
- **backend** — Node.js + GraphQL (Apollo), menyimpan data di Postgres & Redis.
- **php-svc** — layanan media internal (normalisasi avatar), hanya di loopback.
- **ops gateway** — gateway API legacy di port `:8090` (dipublikasikan di
  `<port layanan>+90`).
- **postgres**, **redis** — penyimpanan data, loopback saja.

## Fitur

- Daftar / masuk anggota (sesi JWT).
- Ruang Baca: tulis & baca surat (forum), laporkan surat, cari surat.
- Tinjau tautan: ambil cuplikan isi sebuah URL.
- Ruang: lihat ruang milik sendiri, jelajah & gabung ruang umum, dirikan ruang
  baru, kirim pesan ke ruang yang kamu ikuti.
- Berkas anggota (profil), preferensi anggota, ekspor data ke PDF, dan lambang
  (avatar) pribadi.

## Menjalankan & patching

Layanan dibangun dan dijalankan oleh harness vulnbox (lihat `../../README.md`).
Source berada di `/app` dan dimiliki `ctfuser`; SSH masuk, ubah file di `/app`,
lalu restart layanan dari panel untuk menerapkan patch. Flag ronde berada di
`/flag.txt` dan dibaca ulang tiap request.
