#!/bin/bash
set -e

PGDATA=/var/lib/postgresql/data
PGBIN="$(ls -d /usr/lib/postgresql/*/bin | head -1)"

mkdir -p "$PGDATA"
chown -R postgres:postgres "$PGDATA"

if [ ! -s "$PGDATA/PG_VERSION" ]; then
    echo "[start] initialising postgres cluster"
    gosu postgres "$PGBIN/initdb" -D "$PGDATA" >/dev/null
    echo "host all all 127.0.0.1/32 trust" >> "$PGDATA/pg_hba.conf"
    gosu postgres "$PGBIN/pg_ctl" -D "$PGDATA" \
        -o "-c listen_addresses=127.0.0.1 -p 5432" -w start
    psql -h 127.0.0.1 -U postgres -v ON_ERROR_STOP=1 -c \
        "CREATE ROLE tarot LOGIN SUPERUSER PASSWORD 'tarot_pw';"
    psql -h 127.0.0.1 -U postgres -v ON_ERROR_STOP=1 -c \
        "CREATE DATABASE tarot OWNER tarot;"
    psql -h 127.0.0.1 -U tarot -d tarot -v ON_ERROR_STOP=1 \
        -f /app/db/init.sql
    psql -h 127.0.0.1 -U tarot -d tarot -v ON_ERROR_STOP=1 -c \
        "UPDATE users SET password_hash = crypt('$(openssl rand -hex 24)', gen_salt('bf')) WHERE username = 'admin';"
    gosu postgres "$PGBIN/pg_ctl" -D "$PGDATA" -w stop
    echo "[start] postgres bootstrap done"
fi

SAML_DIR=/app/backend/keys
if [ ! -f "$SAML_DIR/idp_private.pem" ]; then
    echo "[start] generating SSO signing key"
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
        -keyout "$SAML_DIR/idp_private.pem" -out "$SAML_DIR/idp_cert.pem" \
        -subj "/CN=idp.tarot.loen" >/dev/null 2>&1
    chmod 644 "$SAML_DIR/idp_cert.pem"
    chmod 600 "$SAML_DIR/idp_private.pem"
    chown svc:svc "$SAML_DIR/idp_private.pem"
fi

export PGBIN
exec /usr/bin/supervisord -c /app/supervisord.conf
