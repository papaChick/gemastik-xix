<?php
header("Content-Type: application/json");

$expectedToken = getenv("INTERNAL_TOKEN") ?: "itk_devtoken_do_not_use_in_prod";
$givenToken = $_SERVER["HTTP_X_INTERNAL_TOKEN"] ?? "";

if (!hash_equals($expectedToken, $givenToken)) {
    http_response_code(403);
    echo json_encode(["error" => "forbidden"]);
    exit;
}

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!is_array($data) || !isset($data["avatarConfig"])) {
    http_response_code(400);
    echo json_encode(["error" => "avatarConfig wajib diisi"]);
    exit;
}

echo json_encode([
    "status" => "ok",
    "normalizedConfig" => $data["avatarConfig"],
]);
