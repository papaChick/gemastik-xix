<?php
header("Content-Type: text/plain");
echo "tarot-club-internal-media-service v0.9-legacy\n";
