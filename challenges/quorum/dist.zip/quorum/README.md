# Quorum — multi-party signing service

A threshold signing service over edwards25519. One signing key is split across
`N = 48` enrolled members; a quorum is `T + 1 = 25` members. The service
publishes the public material (including the per-round binding mask), offers an
operator audit of individual member shares, and completes a signature from a
quorum. The round's record is read fresh from `/flag.txt` when a signature is
accepted.

## Port & access

- **23000** — the web service
- **23022** — SSH (user `ctfuser`, password from the Services panel)

The source (`src/`) lives in `/app` and is owned by `ctfuser`. Edit it, then
restart the service from the panel. The service runs as the unprivileged `svc`
user, so a bug in it does not hand out a shell as the account that patches.

## Endpoints

| route | purpose |
| --- | --- |
| `GET /` | web console |
| `GET /params` | public material |
| `POST /audit {indices}` | operator audit — reveals member shares, capped at `t` |
| `POST /sign {z}` | submit the response that completes a signature |

## Defending

Keep any fix small enough that `/params`, `/audit` and legitimate signing all
keep working; a patch that rips an endpoint out costs availability on the SLA
check.
