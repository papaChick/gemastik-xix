import hashlib
import os

import ed25519
from ed25519 import L

N = 48
T = 24
_C0 = int.from_bytes(os.urandom(32), "big") % L
_C1 = int.from_bytes(os.urandom(32), "big") % L


def _coeffs():
    coeffs = [_C0 % L, _C1 % L]
    h = hashlib.sha256(b"quorum/ledger/v1").digest()
    for _ in range(2, T + 1):
        h = hashlib.sha256(h).digest()
        coeffs.append(int.from_bytes(h, "big") % L)
    return coeffs


_COEFFS = _coeffs()


def share(x):
    acc = 0
    for c in reversed(_COEFFS):
        acc = (acc * x + c) % L
    return acc


def _enrollment_offsets():
    steps = []
    h = hashlib.sha256(b"quorum/steps").digest()
    for k in range(N - 2):
        steps.append(2 + (h[k % 32] % 3))
    offs = [0, 1]
    for s in steps:
        offs.append(offs[-1] * s)
    return [o % L for o in offs]


_OFF = _enrollment_offsets()
X = [pow((1 + _OFF[i]) % L, L - 2, L) for i in range(N)]

PK = ed25519.mult_base(_C0)
R = ed25519.mult_base(_C1)
Y = [ed25519.mult_base(share(x)) for x in X]

K = int.from_bytes(hashlib.sha256(b"quorum/bind/K").digest(), "big") % L
M = int.from_bytes(hashlib.sha256(b"quorum/bind/M").digest(), "big") % L


def _pending_target():
    h = hashlib.sha256(b"quorum/request/v1").digest()
    seed = int.from_bytes(h, "big")
    pool = list(range(1, N))
    picks = []
    for _ in range(T):
        seed = (seed * 6364136223846793005 + 1442695040888963407) & ((1 << 64) - 1)
        j = seed % len(pool)
        picks.append(pool.pop(j))
    c = 0
    for i in picks:
        c = (c + pow(X[i], L - 2, L)) % L
    return (K * ((c - T) % L) + M) % L


C_SEALED = _pending_target()


def challenge_from_sealed():
    y = (pow(K, L - 2, L) * ((C_SEALED - M) % L)) % L
    return (y + T) % L


def verify(z):
    c = challenge_from_sealed()
    lhs = ed25519.mult_base(z)
    rhs = ed25519._add(R, ed25519.scalar_mult(c, PK))
    return ed25519.eq(lhs, rhs)
