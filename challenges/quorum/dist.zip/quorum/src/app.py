import os

from flask import Flask, Response, jsonify, request, send_from_directory

import ed25519
import ledger

app = Flask(__name__, static_folder="static", static_url_path="")

FLAG_PATH = os.environ.get("FLAG_PATH", "/flag.txt")


def _read_flag():
    try:
        with open(FLAG_PATH) as fh:
            return fh.read().strip()
    except OSError:
        return "GEMASTIK{flag_unavailable}"


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/params")
def params():
    return jsonify(
        {
            "p": str(ledger.L),
            "n": ledger.N,
            "t": ledger.T,
            "x": [str(x) for x in ledger.X],
            "pk": ed25519.encode(ledger.PK).hex(),
            "R": ed25519.encode(ledger.R).hex(),
            "Y": [ed25519.encode(y).hex() for y in ledger.Y],
            "target": str(ledger.C_SEALED),
            "bind": {"K": str(ledger.K), "M": str(ledger.M)},
        }
    )


@app.post("/audit")
def audit():
    data = request.get_json(silent=True) or {}
    indices = data.get("indices", [])
    if not isinstance(indices, list):
        return Response("indices must be a list", status=400)
    indices = sorted(set(int(i) for i in indices))
    if any(i < 0 or i >= ledger.N for i in indices):
        return Response("index out of range", status=400)
    if len(indices) > ledger.T:
        return Response("audit is capped at t shares", status=403)
    shares = {str(i): str(ledger.share(ledger.X[i])) for i in indices}
    return jsonify({"shares": shares})


@app.post("/sign")
def sign():
    data = request.get_json(silent=True) or {}
    z = data.get("z", None)
    if z is None:
        return Response("missing response z", status=400)
    try:
        z = int(z) % ledger.L
    except (TypeError, ValueError):
        return Response("z must be an integer", status=400)

    if ledger.verify(z):
        return jsonify({"ok": True, "record": _read_flag()})
    return jsonify({"ok": False}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
