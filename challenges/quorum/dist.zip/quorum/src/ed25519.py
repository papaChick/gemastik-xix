P = 2 ** 255 - 19
L = 2 ** 252 + 27742317777372353535851937790883648493
D = (-121665 * pow(121666, P - 2, P)) % P


def _inv(x):
    return pow(x, P - 2, P)


def _recover_x(y, sign):
    xx = (y * y - 1) * _inv(D * y * y + 1) % P
    x = pow(xx, (P + 3) // 8, P)
    if (x * x - xx) % P != 0:
        x = x * pow(2, (P - 1) // 4, P) % P
    if x % 2 != sign:
        x = P - x
    return x


_By = 4 * _inv(5) % P
_Bx = _recover_x(_By, 0)
B = (_Bx, _By, 1, _Bx * _By % P)


def _add(a, b):
    ax, ay, az, at = a
    bx, by, bz, bt = b
    A = (ay - ax) * (by - bx) % P
    Bb = (ay + ax) * (by + bx) % P
    C = 2 * at * bt * D % P
    Dd = 2 * az * bz % P
    E = Bb - A
    F = Dd - C
    G = Dd + C
    H = Bb + A
    return (E * F % P, G * H % P, F * G % P, E * H % P)


def scalar_mult(s, point):
    s %= L
    result = (0, 1, 1, 0)
    addend = point
    while s:
        if s & 1:
            result = _add(result, addend)
        addend = _add(addend, addend)
        s >>= 1
    return result


def mult_base(s):
    return scalar_mult(s, B)


def encode(point):
    x, y, z, _ = point
    zi = _inv(z)
    x = x * zi % P
    y = y * zi % P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def eq(a, b):
    return encode(a) == encode(b)
