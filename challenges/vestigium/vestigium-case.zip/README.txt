VESTIGIUM audit archive / Case 17
This is a synthetic historical incident from an earlier key epoch and round.
All names, records, credentials, values, and traffic are fictional.
Verify the included files with checksums.txt before analysis. Timestamps are UTC.
The archive demonstrates formats and an earlier incident; use live service values for current submissions.
